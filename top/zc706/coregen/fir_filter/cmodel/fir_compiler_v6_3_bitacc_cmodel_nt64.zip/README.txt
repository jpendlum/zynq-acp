                Core name: Xilinx FIR Compiler C model
                Version: 6.3.1
                Release Date: January 18, 2012


================================================================================

This document contains the following sections:

1. Introduction
2. New Features
3. Supported Platforms
4. Resolved Issues
5. Known Issues
6. Technical Support
7. Other Information
8. Core Release History
9. Legal Disclaimer

================================================================================


1. INTRODUCTION

For installation instructions for this release, please go to:

   http://www.xilinx.com/ipcenter/coregen/ip_update_install_instructions.htm

For system requirements:

   http://www.xilinx.com/ipcenter/coregen/ip_update_system_requirements.htm

This file contains release notes for the Xilinx LogiCORE IP FIR Compiler v6.3
C Model. For the latest updates, see the product page at:
   
   http://www.xilinx.com/products/intellectual-property/FIR_Compiler.htm

2. NEW FEATURES

   - MATLAB MEX function.

3. SUPPORTED PLATFORMS

The following platfoms are supported by the core for this release:
   
   - Windows NT 32-bit and 64-bit - built using MicroSoft VisualStudio 2008
   - Linux 32-bit and 64-bit      - built using GCC 4.1.1

4. RESOLVED ISSUES

   - FIR Compiler C Model issues:
      o Include Maximize Dynamic Range coefficient scaling in accumulator width calculation to match GUI behaviour
      o Copy taken of cnfg_packet and rld_packet contents when passed to the model rather than only retaining the pointer
      o Copy taken of model name string (xip_fir_v6_3_config.name) rather than only retaining the pointer
      o Ensure that config packet fsel values are ignored if the model is configured with a single coefficient set
     - CR 635759
     
   - FIR Compiler C Model - Errors out when coeff_fract_width > coeff_width
     - CR 637999

5. KNOWN ISSUES

The most recent information, including known issues, workarounds, and
resolutions for this version is provided in the IP Release Notes Guide
located at

   www.xilinx.com/support/documentation/user_guides/xtp025.pdf


6. TECHNICAL SUPPORT

To obtain technical support, create a WebCase at www.xilinx.com/support.
Questions are routed to a team with expertise using this product.

Xilinx provides technical support for use of this product when used
according to the guidelines described in the core documentation, and
cannot guarantee timing, functionality, or support of this product for
designs that do not follow specified guidelines.


7. OTHER INFORMATION

   Full documentation of the C model is provided in the document
   "ug853_fir_compiler_cmodel.pdf".

   Portions of the deliverables provided, specifically the MPIR library, are
   governed by the GNU Lesser General Public License.  See section 9 in
   this README, the source code for these portions, and the accompanying
   FIR Compiler C model User Guide for details.

   Source code for the MPIR library, the MPFR library, and the Visual
   Studio project files for MPFR, can be obtained from
   www.xilinx.com/guest_resources/gnu/


8. CORE RELEASE HISTORY

Date        By            Version      Description
================================================================================
01/18/2012  Xilinx, Inc.  6.3.1        MATLAB MEX function added
10/19/2011  Xilinx, Inc.  6.3          First release of C model, for FIR Compiler v6.3
================================================================================


9. LEGAL DISCLAIMER

(c) Copyright 2011-2012 Xilinx, Inc. All rights reserved.

This file contains confidential and proprietary information
of Xilinx, Inc. and is protected under U.S. and 
international copyright and other intellectual property
laws.

DISCLAIMER
This disclaimer is not a license and does not grant any
rights to the materials distributed herewith. Except as
otherwise provided in a valid license issued to you by
Xilinx, and to the maximum extent permitted by applicable
law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
(2) Xilinx shall not be liable (whether in contract or tort,
including negligence, or under any other theory of
liability) for any loss or damage of any kind or nature
related to, arising under or in connection with these
materials, including for any direct, or any indirect,
special, incidental, or consequential loss or damage
(including loss of data, profits, goodwill, or any type of
loss or damage suffered as a result of any action brought
by a third party) even if such damage or loss was
reasonably foreseeable or Xilinx had been advised of the
possibility of the same.

CRITICAL APPLICATIONS
Xilinx products are not designed or intended to be fail-
safe, or for use in any application requiring fail-safe
performance, such as life-support or safety devices or
systems, Class III medical devices, nuclear facilities,
applications related to the deployment of airbags, or any
other applications that could lead to death, personal
injury, or severe property or environmental damage
(individually and collectively, "Critical
Applications"). Customer assumes the sole risk and
liability of any use of Xilinx products in Critical
Applications, subject only to applicable laws and
regulations governing limitations on product liability.

THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
PART OF THIS FILE AT ALL TIMES.